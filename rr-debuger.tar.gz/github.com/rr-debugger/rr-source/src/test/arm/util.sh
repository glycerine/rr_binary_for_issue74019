TEST_PREFIX=arm/
source `dirname $0`/../util.sh
